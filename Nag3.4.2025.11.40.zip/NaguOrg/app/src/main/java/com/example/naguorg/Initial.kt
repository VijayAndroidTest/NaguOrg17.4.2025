package com.example.naguorg

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row


import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.naguorg.ui.theme.NaguOrgTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

class Initial : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        FirebaseApp.initializeApp(this@Initial)
        val firebaseAppCheck = FirebaseAppCheck.getInstance()
        firebaseAppCheck.installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )

        setContent {
            var showSplash by remember { mutableStateOf(true) }
            var isLoggedIn by remember { mutableStateOf(false) } // Track login status
            val auth = remember { FirebaseAuth.getInstance() }

            LaunchedEffect(Unit) {
                delay(3000) // Show splash screen for 3 seconds
                showSplash = false
                isLoggedIn = auth.currentUser != null // Check if user is already logged in
            }

            when {
                showSplash -> SplashScreen()
                !isLoggedIn -> LoginScreen(onLoginSuccess = { isLoggedIn = true })
                else -> NaguOrganics()
            }
        }
    }
}


@Composable
fun SplashScreen() {

    val context = LocalContext.current

    AndroidView(
        factory = { ctx ->
            VideoView(ctx).apply {
                setVideoURI(Uri.parse("android.resource://${context.packageName}/raw/splashvideonew"))
                setOnPreparedListener { it.start() }
            }
        },
        modifier = Modifier.fillMaxSize()
    )


}

@Composable
fun NaguOrganics() {

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        Spacer(modifier = Modifier.height(16.dp))
        BannerImage()
        availProductBtn()
        ContactSection()

    }
}

@Composable
fun BannerImage() {


    Column(
        modifier = Modifier
            .fillMaxWidth(),

        horizontalAlignment = Alignment.CenterHorizontally // Centers content horizontally
    ) {
        Text(
            text = stringResource(R.string.welcome_message),
            fontSize = 25.sp,
            color = Color.Red,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        val image: Painter = painterResource(id = R.drawable.nagu_organics_logo)
        Image(
            painter = image,
            contentDescription = "Nagu Organics Banner",
            modifier = Modifier.padding(top = 6.dp)
        )
    }

}

@Composable
fun availProductBtn() {

}



@Composable
fun ContactSection() {
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 20.dp), // Added bottom margin
        contentAlignment = Alignment.BottomCenter // Align content to the bottom
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            // Product List Button
            Button(
                onClick = {
                    val intent = Intent(context, MainActivity::class.java)
                    context.startActivity(intent)
                    Toast.makeText(context, "Product List", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 50.dp) // Margin between button and social media
            ) {
                Text(text = stringResource(R.string.product_list_button))
            }

            // Social Media Section
            Text(
                text = "Follow us on:",
                fontSize = 18.sp,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp), // Bottom margin for social media icons
                horizontalArrangement = Arrangement.Center
            ) {
                SocialMediaIcon(
                    iconRes = R.drawable.call,
                    action = {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:8838380787")
                        }
                        context.startActivity(intent)
                    }
                )
                Spacer(modifier = Modifier.padding(8.dp))

                SocialMediaIcon(
                    iconRes = R.drawable.wapp,
                    action = {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://wa.me/918838380787")
                        }
                        context.startActivity(intent)
                    }
                )
                Spacer(modifier = Modifier.padding(8.dp))

                SocialMediaIcon(
                    iconRes = R.drawable.facebook,
                    url = "https://www.facebook.com/naguorganics",
                    context = context
                )
                Spacer(modifier = Modifier.padding(8.dp))

                SocialMediaIcon(
                    iconRes = R.drawable.insta,
                    url = "https://www.instagram.com/naguorganics",
                    context = context
                )
                Spacer(modifier = Modifier.padding(8.dp))

                SocialMediaIcon(
                    iconRes = R.drawable.twitter,
                    url = "https://twitter.com/naguorganics",
                    context = context
                )
            }
        }
    }
    }


@Composable
fun SocialMediaIcon(iconRes: Int, url: String, context: android.content.Context) {
    Image(
        painter = painterResource(id = iconRes),
        contentDescription = "Social Media Icon",
        modifier = Modifier
            .clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
            }
            .height(40.dp)
            .padding(4.dp)
    )
}