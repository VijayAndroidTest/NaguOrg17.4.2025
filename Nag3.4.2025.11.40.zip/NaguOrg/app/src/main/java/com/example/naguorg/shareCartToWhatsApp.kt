package com.example.naguorg

import android.content.Context
import android.content.Intent
import android.net.Uri


fun shareCartToWhatsApp(context: Context, cartItems: List<Product>, phoneNumber: String) {
    val message = buildCartMessage(cartItems)

    val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phoneNumber&text=${Uri.encode(message)}")
    val intent = Intent(Intent.ACTION_VIEW, uri)

    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Handle the case where WhatsApp is not installed
        e.printStackTrace()
    }
}

fun buildCartMessage(cartItems: List<Product>): String {
    val messageBuilder = StringBuilder("🛒 *Order Summary* 📦\n\n")

    for (product in cartItems) {
        messageBuilder.append("🔹 *${product.name}*\n")
        messageBuilder.append("   ₹${product.price} x ${product.quantity}\n\n")
    }

    messageBuilder.append("✅ *Total Price:* ₹${cartItems.sumOf { it.price.toDouble() * it.quantity }}\n")
    messageBuilder.append("\n📍 *Registered Address:* ( Nagu Organics :5/124,Sundaram plaza,Near Golden Trendz,B.s sundaram Street, Avinasi-641654 )\n")

    return messageBuilder.toString()
}