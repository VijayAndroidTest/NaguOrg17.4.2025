package com.example.naguorg

import android.content.Intent
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest

import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.google.gson.Gson
// Declare cartList globally or inside a ViewModel
val cartList = mutableListOf<Product>()

@Composable
fun ProductItem(product: Product,  onAddToCart: (Product) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxWidth()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDialog = true }
                .padding(2.dp),
            shape = RoundedCornerShape(2.dp),
            elevation = CardDefaults.cardElevation(0.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ProductImage(image = product.image, onClick = { showDialog = true })

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = buildAnnotatedString {
                        append("Price: ")
                        withStyle(style = SpanStyle(color = Color.Magenta)) {
                            append("₹${product.price}") }
                    },
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Add to Cart Button
                val context = LocalContext.current
                Button(
                    onClick = {
                        cartList.add(product)  // ✅ Add product to cart
                        onAddToCart(product)   // ✅ Notify parent about the addition
                        val intent = Intent(context, CartActivity::class.java).apply {
                            putParcelableArrayListExtra("cartItems", ArrayList(cartList))
                        }
                        context.startActivity(intent)
                        Log.d("Cart", "Cart Items: $cartList")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007BFF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Add to cart", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 🔥 Discount Label at the Top-Right Corner
        if (product.disc.isNotEmpty()) {
            Text(
                text = "${product.disc}% OFF",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(Color.Red, shape = RoundedCornerShape(bottomStart = 8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }

    if (showDialog) {
        ZoomableImageDialog(imageUrl = product.image) { showDialog = false }
    }
}




@Composable
fun ProductImage(image: String?, onClick: () -> Unit) {
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(image)
            .crossfade(true)
            .error(R.drawable.naguback)
            .placeholder(R.drawable.naguback)
            .build(),
        contentDescription = "Product Image",
        modifier = Modifier
            .size(170.dp) // Increased size for visibility
            .clip(RoundedCornerShape(5.dp))
            .background(Color.LightGray.copy(alpha = 0.3f))
            .clickable { onClick() } // Clickable effect
            .shadow(8.dp, shape = RoundedCornerShape(3.dp)), // Shadow for highlighting
        contentScale = ContentScale.Crop
    )
}

@Composable
fun ZoomableImageDialog(imageUrl: String, onDismiss: () -> Unit) {
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.8f))
                .clickable { onDismiss() }
        ) {
            Box(
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 3f)
                            offsetX = (offsetX + pan.x).coerceIn(-200f, 200f)
                            offsetY = (offsetY + pan.y).coerceIn(-200f, 200f)
                        }
                    }
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
            ) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}