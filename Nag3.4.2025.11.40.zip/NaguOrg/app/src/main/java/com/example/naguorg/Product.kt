package com.example.naguorg

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
@Parcelize
data class Product(   val name: String = "",
                      val disc: String = "",
                      val price: Int = 0,  // Changed from String to Int
                      val image: String = "",
                      var quantity: Int = 1 // Allow quantity changes
) : Parcelable
