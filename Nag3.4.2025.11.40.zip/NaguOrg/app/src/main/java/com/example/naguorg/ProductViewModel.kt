package com.example.naguorg

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ProductViewModel : ViewModel() {
    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products

    init {
        fetchProducts()
    }

    fun fetchProducts() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val db = FirebaseFirestore.getInstance()
                val result = db.collection("products").get().await()
                val fetchedProducts = result.documents.mapNotNull { it.toObject(Product::class.java) }

                _products.value = fetchedProducts
                Log.d("Firestore", "Fetched ${fetchedProducts.size} products")
            } catch (e: Exception) {
                Log.e("Firestore", "Error fetching products", e)
            }
        }
    }
}