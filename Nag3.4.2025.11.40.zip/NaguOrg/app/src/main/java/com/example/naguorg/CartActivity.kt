package com.example.naguorg

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter


class CartActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cartItems: ArrayList<Product>? = intent.getParcelableArrayListExtra("cartItems")

        enableEdgeToEdge()
        setContent {
            CartScreen(cartItems ?: emptyList())
        }

        Log.d("CartActivity", "Received Cart Items: ${cartItems?.size}")
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(cartItems: List<Product>) {

  val activity = (LocalContext.current as? ComponentActivity)

    var items by remember { mutableStateOf(cartItems.distinctBy { it.name }.map { it.copy(quantity = 1) }) }
    var totalPrice by remember { mutableStateOf(0.0) }

    // Recalculate total price whenever cart updates
    LaunchedEffect(items) {
        totalPrice = items.sumOf { it.price.toDouble() * it.quantity }
    }

    Scaffold(
        topBar = {
            TopAppBar(

                title = { Text("My Cart") },

                navigationIcon = {
                    IconButton(onClick = { activity?.onBackPressedDispatcher?.onBackPressed() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = { CartBottomBar(totalPrice, items, LocalContext.current) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(items) { product ->
                    CartItem(
                        product = product,
                        onQuantityChange = { updatedProduct ->
                            items = items.map { if (it.name == updatedProduct.name) updatedProduct else it }
                        },
                        onDelete = {
                            items = items.filter { it.name != product.name } // 🔥 Proper deletion
                        }
                    )
                }
            }
        }
    }
}
@Composable
fun CartItem(
    product: Product,
    onQuantityChange: (Product) -> Unit,
    onDelete: () -> Unit // New delete action
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = rememberAsyncImagePainter(product.image),
                    contentDescription = null,
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.White)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = product.name, style = MaterialTheme.typography.bodyLarge)
           // Text(text = product.disc, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "₹${product.price}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Quantity Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        if (product.quantity > 1) {
                            onQuantityChange(product.copy(quantity = product.quantity - 1))
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7))
                ) {
                    Text("-")
                }

                Text(
                    text = "  Qty: ${product.quantity}  ",
                    style = MaterialTheme.typography.bodyMedium
                )

                Button(
                    onClick = { onQuantityChange(product.copy(quantity = product.quantity + 1)) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7))
                ) {
                    Text("+")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Buy and Delete Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = {
                        shareCartToWhatsApp(context, listOf(product), "918838380787")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006400))
                ) {
                    Text("Buy", color = Color.White)
                }

                Button(
                    onClick = { onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Delete", color = Color.White)
                }
            }
        }
    }
}
@Composable
fun CartBottomBar(totalPrice: Double, cartItems: List<Product>, context: Context) {
    val isCartEmpty = cartItems.isEmpty() // Check if the cart is empty

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(16.dp)
            .navigationBarsPadding() // Avoids cut-off
    ) {
        Text(
            text = "Total Price: ₹${String.format("%.2f", totalPrice)}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (!isCartEmpty) {
                    shareCartToWhatsApp(context, cartItems, "918838380787")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7)),
            enabled = !isCartEmpty // 🔥 Disable button if cart is empty
        ) {
            Text("Buy Now WhatsApp")
        }

        // Show a warning message if the cart is empty
        if (isCartEmpty) {
            Text(
                text = "Your cart is empty! Add items before proceeding.",
                color = Color.Red,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}